package com.vanhackchallenge.base.mvc.command;

import android.content.Context;

public interface ICommand<I> {

    public void execute(Context context, I i) throws Exception;

}
