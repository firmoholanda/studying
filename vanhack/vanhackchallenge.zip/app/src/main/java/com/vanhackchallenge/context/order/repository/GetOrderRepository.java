package com.vanhackchallenge.context.order.repository;

import android.content.Context;

import com.vanhackchallenge.base.mvc.interfaces.IRepositoryListener;
import com.vanhackchallenge.base.mvc.repository.AbstractRepository;
import com.vanhackchallenge.base.mvc.service.manager.IRestHandler;
import com.vanhackchallenge.base.mvc.service.manager.IRestProcessor;
import com.vanhackchallenge.base.mvc.service.manager.RestProcessorManager;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;
import com.vanhackchallenge.context.order.rest.handler.GetOrderRestHandler;
import com.vanhackchallenge.context.order.rest.processor.GetOrderRestProcessor;

public class GetOrderRepository extends AbstractRepository<Integer, ReturnModel> {

    private ReturnModel model;

    public GetOrderRepository(IRepositoryListener<ReturnModel> listener, Context context) {
        super(listener, context);
    }

    @Override
    protected ReturnModel fromDao(Integer uid) {
        return null;
    }

    @Override
    protected ReturnModel fromServices(Integer uid) {
        IRestProcessor<Integer, ReturnModel> processor = new GetOrderRestProcessor();
        IRestHandler<ReturnModel> handler = new GetOrderRestHandler();
        return new RestProcessorManager<Integer, ReturnModel>(processor, handler).process(context, uid);
    }

    @Override
    protected boolean isDaoValid(ReturnModel returnModel) {
        return false;
    }

    @Override
    protected ReturnModel getInvalidDao() {
        return model;
    }
}