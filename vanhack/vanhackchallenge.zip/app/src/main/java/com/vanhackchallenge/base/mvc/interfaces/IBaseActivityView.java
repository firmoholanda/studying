package com.vanhackchallenge.base.mvc.interfaces;

import android.databinding.ViewDataBinding;

public interface IBaseActivityView {

    public void initializeViews(ViewDataBinding viewDataBinding);

    public void setListeners(ViewDataBinding viewDataBinding);

    public void unbind();

}
