package com.vanhackchallenge.application;

import android.app.Application;
import android.content.Context;

public class VanHackApplication extends Application {

    public static VanHackApplication context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
    }

    /**
     * Return the application context.
     * Always available
     *
     * @return  the application context
     */
    public static Context getContext(){
        return context;
    }

}
