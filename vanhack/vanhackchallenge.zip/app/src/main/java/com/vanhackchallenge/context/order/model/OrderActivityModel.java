package com.vanhackchallenge.context.order.model;

import com.vanhackchallenge.base.mvc.BaseActivityModel;

public class OrderActivityModel extends BaseActivityModel {

    public static final String ORDER_CHANGED = "ORDER_CHANGED";

    private Integer orderId;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
        this.setChanged();
        this.notifyObservers(ORDER_CHANGED);
    }

}
