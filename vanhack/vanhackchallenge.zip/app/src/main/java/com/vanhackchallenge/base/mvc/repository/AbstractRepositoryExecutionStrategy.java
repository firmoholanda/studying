package com.vanhackchallenge.base.mvc.repository;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public abstract class AbstractRepositoryExecutionStrategy<I, R extends AbstractModel> {

    public AbstractRepository<I, R> repository;

    public abstract void execute(final I i);

    public AbstractRepositoryExecutionStrategy(AbstractRepository<I, R> repo){
        this.repository = repo;
    }

}
