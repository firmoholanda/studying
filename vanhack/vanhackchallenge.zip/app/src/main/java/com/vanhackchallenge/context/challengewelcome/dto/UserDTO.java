package com.vanhackchallenge.context.challengewelcome.dto;

public class UserDTO {

    private String token;
    private String mail;
    private String photo;

    public UserDTO(String token, String mail, String photo) {
        this.token = token;
        this.mail = mail;
        this.photo = photo;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
