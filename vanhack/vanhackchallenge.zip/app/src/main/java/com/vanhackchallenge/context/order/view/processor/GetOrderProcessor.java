package com.vanhackchallenge.context.order.view.processor;

import com.vanhackchallenge.application.VanHackApplication;
import com.vanhackchallenge.base.enums.EntityEnums;
import com.vanhackchallenge.base.mvc.processor.IMatchProcessor;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;
import com.vanhackchallenge.context.order.OrderActivity;
import com.vanhackchallenge.context.order.command.GetOrderCommand;
import com.vanhackchallenge.context.order.model.OrderActivityModel;

public class GetOrderProcessor implements IMatchProcessor {

    private OrderActivity activity;

    public GetOrderProcessor(OrderActivity activity){
        this.activity = activity;
    }

    @Override
    public boolean match(Object object) {
        ReturnModel returnModel = (ReturnModel) object;
        return object != null && EntityEnums.GET_ORDER.equals(returnModel.getCommandType());
    }

    @Override
    public Object execute() {
        // Execute validations on return and set on model
        return null;
    }
}
