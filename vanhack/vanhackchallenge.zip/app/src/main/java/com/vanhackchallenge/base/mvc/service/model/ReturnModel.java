package com.vanhackchallenge.base.mvc.service.model;

public class ReturnModel extends AbstractModel {

    public ReturnModel() {
    }

    public ReturnModel(Exception e) {
        this.exception = e;
    }

    /* (non-Javadoc)
     * @see br.com.gvt.infra.model.AbstractModel#getPayload()
     */
    @Override
    public Object getPayload() {
        return this.payload;
    }

    /* (non-Javadoc)
     * @see br.com.gvt.infra.model.AbstractModel#setPayload(java.lang.Object)
     */
    @Override
    public void setPayload(Object payload) {
        this.payload = payload;
    }
}
