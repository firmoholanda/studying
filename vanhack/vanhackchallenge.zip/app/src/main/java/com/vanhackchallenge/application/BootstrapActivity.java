package com.vanhackchallenge.application;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Window;

import com.vanhackchallenge.R;
import com.vanhackchallenge.base.mvc.BaseActivity;
import com.vanhackchallenge.base.mvc.annotations.ActivityLayout;
import com.vanhackchallenge.base.mvc.annotations.ActivityModel;
import com.vanhackchallenge.base.mvc.annotations.ActivityView;
import com.vanhackchallenge.context.challengewelcome.ChallengeWelcomeActivity;
import com.vanhackchallenge.context.order.OrderActivity;
import com.vanhackchallenge.databinding.ActivityBootstrapBinding;

import java.util.Observable;

@ActivityModel(ignore = true)
@ActivityView(ignore = true)
@ActivityLayout(layout = R.layout.activity_bootstrap)
public class BootstrapActivity extends BaseActivity{

    @Override
    public void executeFirstLoad(Bundle savedInstanceState) {
        new Handler().postDelayed(() -> beginApp(), 1200);
    }

    private void beginApp() {
        Intent intent = new Intent(this, ChallengeWelcomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public void update(Observable o, Object arg) {

    }

}
