package com.vanhackchallenge.context.challengewelcome.view.processors;

import android.content.Intent;

import com.vanhackchallenge.application.VanHackApplication;
import com.vanhackchallenge.base.mvc.processor.IMatchProcessor;
import com.vanhackchallenge.context.challengewelcome.ChallengeWelcomeActivity;
import com.vanhackchallenge.context.challengewelcome.model.WelcomeChallengeActivityModel;
import com.vanhackchallenge.context.order.OrderActivity;

public class WelcomeOrderProcessor implements IMatchProcessor {

    private ChallengeWelcomeActivity activity;

    public WelcomeOrderProcessor(ChallengeWelcomeActivity activity){
        this.activity = activity;
    }

    @Override
    public boolean match(Object object) {
        return object != null && WelcomeChallengeActivityModel.UID_CHANGED.equals(object);
    }

    @Override
    public Object execute() {
        Intent intent = new Intent(VanHackApplication.getContext(), OrderActivity.class);
        intent.putExtra("uid", ((WelcomeChallengeActivityModel) activity.getActivityModel()).getUid());
        VanHackApplication.getContext().startActivity(intent);
        return null;
    }
}
