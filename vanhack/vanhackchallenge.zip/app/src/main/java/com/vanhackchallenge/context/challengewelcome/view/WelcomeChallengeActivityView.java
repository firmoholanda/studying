package com.vanhackchallenge.context.challengewelcome.view;

import android.content.Intent;
import android.databinding.ViewDataBinding;

import com.vanhackchallenge.application.VanHackApplication;
import com.vanhackchallenge.base.mvc.BaseActivityView;
import com.vanhackchallenge.context.challengewelcome.model.WelcomeChallengeActivityModel;
import com.vanhackchallenge.context.order.OrderActivity;
import com.vanhackchallenge.databinding.ActivityChallengeWelcomeBinding;

public class WelcomeChallengeActivityView extends BaseActivityView {

    @Override
    public void initializeViews(ViewDataBinding viewDataBinding) {

    }

    @Override
    public void setListeners(ViewDataBinding viewDataBinding) {
        System.out.println();
        ((ActivityChallengeWelcomeBinding) viewDataBinding).btMockFishOrder.setOnClickListener(v -> doOrder(1));
        ((ActivityChallengeWelcomeBinding) viewDataBinding).btMockPastaOrder.setOnClickListener(v -> doOrder(2));
        ((ActivityChallengeWelcomeBinding) viewDataBinding).btMockRomanticOrder.setOnClickListener(v -> doOrder(3));
    }

    private void doOrder(Integer uid){
        ((WelcomeChallengeActivityModel) getBaseActivity().getActivityModel()).setUid(uid);
    }


}
