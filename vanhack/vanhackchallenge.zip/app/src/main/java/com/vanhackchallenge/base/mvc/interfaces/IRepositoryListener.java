package com.vanhackchallenge.base.mvc.interfaces;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public interface IRepositoryListener<R extends AbstractModel> {

    public void repositorySuccess(R r);

    public void repositoryFail(R r);

}
