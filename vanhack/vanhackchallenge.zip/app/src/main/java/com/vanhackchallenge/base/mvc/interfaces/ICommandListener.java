package com.vanhackchallenge.base.mvc.interfaces;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public interface ICommandListener<T extends AbstractModel> {

    public void commandSuccess(T success);

    public void commandFail(T fail);

}
