package com.vanhackchallenge.application.constants;

public interface AppUrlConstants {

    String BASE_URL_MOBILE = "http://10.0.2.2:8080/";
    String BASE_VANHACK = "http://172.16.12.82:8080/";


}
