package com.vanhackchallenge.context.order.view;

import android.databinding.ViewDataBinding;

import com.vanhackchallenge.base.mvc.BaseActivityView;

public class OrderActivityView extends BaseActivityView {

    @Override
    public void initializeViews(ViewDataBinding viewDataBinding) {
        System.out.println(viewDataBinding);
    }

    @Override
    public void setListeners(ViewDataBinding viewDataBinding) {

    }
}
