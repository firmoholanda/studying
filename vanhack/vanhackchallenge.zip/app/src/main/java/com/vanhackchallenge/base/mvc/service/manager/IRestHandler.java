package com.vanhackchallenge.base.mvc.service.manager;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public interface IRestHandler<R extends AbstractModel> {

    /**
     * Retorna o resultado da execucao do servico
     *
     * @param t
     */
    public R success(R r);

    /**
     * Executado quando ocorre um erro no processamento
     *
     * @param error
     */
    public R fail(Exception e, Object incoming);

}
