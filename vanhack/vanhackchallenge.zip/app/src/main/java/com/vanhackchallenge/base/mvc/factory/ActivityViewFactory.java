package com.vanhackchallenge.base.mvc.factory;

import com.vanhackchallenge.base.mvc.BaseActivity;
import com.vanhackchallenge.base.mvc.BaseActivityView;
import com.vanhackchallenge.base.mvc.annotations.ActivityView;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;

public class ActivityViewFactory {

    private ActivityViewFactory(){}
    private static ActivityViewFactory instance;
    private static Map<String, BaseActivityView> mapView;

    public static ActivityViewFactory getInstance(){
        if (instance == null){
            instance = new ActivityViewFactory();
            mapView = new HashMap<String, BaseActivityView>();
        }
        return instance;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private String getActivityViewName(Class clazz) throws IllegalAccessException {
        Annotation annotation = clazz.getAnnotation(ActivityView.class);
        if(annotation instanceof ActivityView){
            ActivityView viewName = (ActivityView) annotation;
            if (viewName.path() != null && viewName.path().trim().length() > 0){
                return viewName.path();
            }
        }
        throw new IllegalAccessException("You must set a view");
    }

    @SuppressWarnings("rawtypes")
    public BaseActivityView getActivityView(BaseActivity baseActivity) throws ClassNotFoundException, InstantiationException, IllegalAccessException{
        if (shouldIgnore(baseActivity.getClass())){
            return null;
        }
        BaseActivityView activityView = mapView.get(baseActivity.getUuid());
        if (activityView == null){
            String activityViewName = getActivityViewName(baseActivity.getClass());
            if (activityViewName == null){
                throw new IllegalArgumentException("Necessario setar a anotassaum @ActivityView(path=) na Activity");
            }
            Class c = Class.forName(activityViewName);
            activityView = (BaseActivityView) c.newInstance();
            mapView.put(baseActivity.getUuid(), activityView);
        }
        return activityView;
    }

    public void cleanActivityView(BaseActivity baseActivity){
        if (mapView.get(baseActivity.getUuid()) != null) {
            mapView.get(baseActivity.getUuid()).unbind();
        }
        mapView.remove(baseActivity.getUuid());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private boolean shouldIgnore(Class clazz){
        Annotation annotation = clazz.getAnnotation(ActivityView.class);
        if(annotation instanceof ActivityView){
            ActivityView viewName = (ActivityView) annotation;
            return viewName.ignore();
        }
        return false;
    }

}
