package com.vanhackchallenge.base.enums;

public enum EntityEnums {

    GET_ORDER

}
