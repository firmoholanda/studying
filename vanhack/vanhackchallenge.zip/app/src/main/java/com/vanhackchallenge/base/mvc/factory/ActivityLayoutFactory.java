package com.vanhackchallenge.base.mvc.factory;

import com.vanhackchallenge.base.mvc.annotations.ActivityLayout;

import java.lang.annotation.Annotation;

public class ActivityLayoutFactory {

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static int getActivityLayout(Class clazz) {
        Annotation annotation = clazz.getAnnotation(ActivityLayout.class);
        if(annotation instanceof ActivityLayout){
            ActivityLayout activityLayout = (ActivityLayout) annotation;
            try{
                if (activityLayout.layout() != -1){
                    return activityLayout.layout();
                }
            } catch (Exception e){
                e.printStackTrace();
            }

        }
        return 0;
    }


}
