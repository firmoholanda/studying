package com.vanhackchallenge.base.mvc;

import java.util.Observable;

public abstract class BaseActivityModel extends Observable {
}
