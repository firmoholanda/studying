package com.vanhackchallenge.base.mvc.repository;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public class DefaultRepositoryStrategy<I, R extends AbstractModel> extends AbstractRepositoryExecutionStrategy<I, R> {

    /**
     * @param repo
     */
    public DefaultRepositoryStrategy(AbstractRepository<I, R> repo) {
        super(repo);
    }

    /* (non-Javadoc)
     * @see br.com.gvt.infra.patterns.strategy.IRepositoryExecutionStrategy#execute(java.lang.Object)
     */
    @Override
    public void execute(final I i) {
        new Thread(){
            public void run() {
                repository.daoReturn = repository.fromDao(i);
                if (repository.isDaoValid(repository.daoReturn)) {
                    repository.listener.repositorySuccess(repository.daoReturn);
                    return;
                }
                R rFromService = repository.fromServices(i);
                R rFromDao = null;

                if (rFromService != null && rFromService.getPayload() != null){
                    repository.listener.repositorySuccess(rFromService);
                    return;
                } else if (rFromService == null || rFromService.getException() != null){
                    rFromDao = repository.getInvalidDao();
                }

                if (rFromDao != null && rFromDao.getPayload() != null){
                    repository.listener.repositorySuccess(rFromDao);
                } else {
                    //Bloco de falha geral de service e DAO
                    if (rFromService != null && rFromService.getCommandType() != null){
                        repository.listener.repositoryFail(rFromService);
                        return;
                    }
                    repository.listener.repositoryFail(rFromDao);
                }
            }
        }.start();

    }

}
