package com.vanhackchallenge.base.mvc.service.manager;

import android.content.Context;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public interface IRestProcessor<I, R extends AbstractModel> {

    public R execute(Context context, I i) throws Exception;

}
