package com.vanhackchallenge.context.challengewelcome;

import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.vanhackchallenge.R;
import com.vanhackchallenge.base.mvc.BaseActivity;
import com.vanhackchallenge.base.mvc.annotations.ActivityLayout;
import com.vanhackchallenge.base.mvc.annotations.ActivityModel;
import com.vanhackchallenge.base.mvc.annotations.ActivityView;
import com.vanhackchallenge.base.mvc.interfaces.IRepositoryListener;
import com.vanhackchallenge.base.mvc.processor.IMatchProcessor;
import com.vanhackchallenge.base.mvc.processor.MatchProcessor;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;
import com.vanhackchallenge.context.challengewelcome.view.processors.WelcomeOrderProcessor;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

@ActivityModel(path = "com.vanhackchallenge.context.challengewelcome.model.WelcomeChallengeActivityModel")
@ActivityView(path = "com.vanhackchallenge.context.challengewelcome.view.WelcomeChallengeActivityView")
@ActivityLayout(layout = R.layout.activity_challenge_welcome)
public class ChallengeWelcomeActivity extends BaseActivity implements IRepositoryListener<ReturnModel>  {

    private MatchProcessor matchProcessor;
    private List<IMatchProcessor> processorUpdateList = new ArrayList<>();;

    @Override
    public void executeFirstLoad(Bundle savedInstanceState) {
        this.processorUpdateList.add(new WelcomeOrderProcessor(this));
    }

    @Override
    public void repositorySuccess(ReturnModel returnModel) {

    }

    @Override
    public void repositoryFail(ReturnModel returnModel) {

    }

    @Override
    public void update(Observable o, Object data) {
        System.out.println();
        new Handler(Looper.getMainLooper()).post(new Runnable() {

            @Override
            public void run() {
                new MatchProcessor(data, processorUpdateList).process();
            }
        });
    }

}
