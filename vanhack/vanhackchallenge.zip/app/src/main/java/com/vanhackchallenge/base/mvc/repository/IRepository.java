package com.vanhackchallenge.base.mvc.repository;

public interface IRepository<I> {

    public void execute(I i);

}