package com.vanhackchallenge.base.mvc.processor;

public interface IMatchProcessor {

    public boolean match(Object object);

    public Object execute();

}
