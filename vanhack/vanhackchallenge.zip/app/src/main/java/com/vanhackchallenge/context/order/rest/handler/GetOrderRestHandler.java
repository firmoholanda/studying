package com.vanhackchallenge.context.order.rest.handler;

import com.vanhackchallenge.base.enums.EntityEnums;
import com.vanhackchallenge.base.mvc.service.manager.IRestHandler;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;

public class GetOrderRestHandler implements IRestHandler<ReturnModel> {

    @Override
    public ReturnModel success(ReturnModel returnModel) {
        //Implements save to dao or something else
        return returnModel;
    }

    @Override
    public ReturnModel fail(Exception e, Object incoming) {
        ReturnModel model = new ReturnModel();
        model.setCommandType(EntityEnums.GET_ORDER);
        model.setException(e);

        return model;
    }
}
