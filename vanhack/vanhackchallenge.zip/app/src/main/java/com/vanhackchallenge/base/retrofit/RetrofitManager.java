package com.vanhackchallenge.base.retrofit;

import android.text.TextUtils;

import com.vanhackchallenge.application.constants.AppUrlConstants;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitManager {

    private OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
    private Retrofit.Builder builder =
            new Retrofit.Builder()
                    .baseUrl(AppUrlConstants.BASE_VANHACK)
                    .addConverterFactory(GsonConverterFactory.create());


    private static RetrofitManager instance;

    private RetrofitManager(){}

    public static RetrofitManager get(){
        if (instance == null){
            instance = new RetrofitManager();
        }
        return instance;
    }

    public <S> S createService(Class<S> serviceClass) {
        return createService(serviceClass, null);
    }

    public <S> S createService(
            Class<S> serviceClass, final String authToken) {

        Retrofit retrofit = null;

        if (!TextUtils.isEmpty(authToken)) {
            AuthenticationInterceptor interceptor =
                    new AuthenticationInterceptor(authToken);

            if (!httpClient.interceptors().contains(interceptor)) {
                httpClient.addInterceptor(interceptor);

                builder.client(httpClient.build());
                retrofit = builder.build();
            }
        } else {
            retrofit = builder.build();
        }

        return retrofit.create(serviceClass);
    }

    /*
    public Retrofit retrofit(){
        if (this.retrofit == null) {
            this.retrofit = new Retrofit.Builder()
                    .baseUrl(AppUrlConstants.BASE_URL_MOBILE)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
    */

}
