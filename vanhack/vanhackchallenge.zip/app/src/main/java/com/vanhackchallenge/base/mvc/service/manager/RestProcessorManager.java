package com.vanhackchallenge.base.mvc.service.manager;

import android.content.Context;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public class RestProcessorManager<I, R extends AbstractModel> {

    private IRestProcessor<I, R> restProcessor;
    private IRestHandler<R> restHandler;

    public RestProcessorManager(IRestProcessor<I, R> restProcessor, IRestHandler<R> restHandler){
        this.restProcessor = restProcessor;
        this.restHandler = restHandler;
    }

    public R process(Context context, I i){
        try {
            return restHandler.success(restProcessor.execute(context, i));
        } catch (Exception e) {
            return restHandler.fail(e, i);
        }
    }

}