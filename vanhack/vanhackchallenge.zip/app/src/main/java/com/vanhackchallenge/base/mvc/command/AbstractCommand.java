package com.vanhackchallenge.base.mvc.command;

import com.vanhackchallenge.base.mvc.interfaces.IRepositoryListener;
import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public abstract class AbstractCommand<I, R extends AbstractModel> implements ICommand<I> {

    protected IRepositoryListener<R> listener;

    public AbstractCommand(IRepositoryListener<R> listener) {
        this.listener = listener;
    }
}
