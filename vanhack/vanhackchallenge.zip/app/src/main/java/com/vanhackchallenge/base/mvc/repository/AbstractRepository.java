package com.vanhackchallenge.base.mvc.repository;

import android.content.Context;

import com.vanhackchallenge.base.mvc.interfaces.IRepositoryListener;
import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public abstract class AbstractRepository<I, R extends AbstractModel> implements IRepository<I> {

    protected Context context;

    protected R daoReturn;

    protected IRepositoryListener<R> listener;

    private AbstractRepositoryExecutionStrategy<I, R> executionStrategy;

    public AbstractRepository(IRepositoryListener<R> listener, Context context){
        this.listener = listener;
        this.context = context;
    }

    protected abstract R fromDao(I i);

    protected abstract R fromServices(I i);

    protected abstract boolean isDaoValid(R r);

    /**
     * Retorna o dao invalido.
     * Caso nao queira utilizar o dao invalido por questoes negociais, retornar null
     * @return
     */
    protected abstract R getInvalidDao();

    /* (non-Javadoc)
     * @see br.com.gvt.infra.patterns.IRepository#execute()
     */
    @Override
    public void execute(final I i) {
        if (this.executionStrategy == null){
            this.executionStrategy = new DefaultRepositoryStrategy<I, R>(this);
        }
        executionStrategy.execute(i);
    }

    /**
     * @param executionStrategy the executionStrategy to set
     */
    public void setExecutionStrategy(AbstractRepositoryExecutionStrategy<I, R> executionStrategy) {
        this.executionStrategy = executionStrategy;
    }

}