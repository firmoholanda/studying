package com.vanhackchallenge.base.mvc.factory;

import com.vanhackchallenge.base.mvc.BaseActivity;
import com.vanhackchallenge.base.mvc.BaseActivityModel;
import com.vanhackchallenge.base.mvc.annotations.ActivityModel;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;

public class ActivityModelFactory {

    private ActivityModelFactory(){}
    private static ActivityModelFactory instance;
    private static Map<String, BaseActivityModel> mapModel;

    public static ActivityModelFactory getInstance(){
        if (instance == null){
            instance = new ActivityModelFactory();
            mapModel = new HashMap<String, BaseActivityModel>();
        }
        return instance;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private String getActivityModelName(Class clazz) throws IllegalAccessException {
        Annotation annotation = clazz.getAnnotation(ActivityModel.class);
        if(annotation instanceof ActivityModel){
            ActivityModel modelName = (ActivityModel) annotation;
            if (modelName.path() != null && modelName.path().trim().length() > 0){
                return modelName.path();
            }
        }
        throw new IllegalAccessException("You must set a model");
    }

    @SuppressWarnings("rawtypes")
    public BaseActivityModel getActivityModel(BaseActivity baseActivity) throws ClassNotFoundException, InstantiationException, IllegalAccessException{
        if (shouldIgnore(baseActivity.getClass())){
            return null;
        }
        BaseActivityModel activityModel = mapModel.get(baseActivity.getUuid());
        if (activityModel == null){
            String activityViewName = getActivityModelName(baseActivity.getClass());
            if (activityViewName == null){
                throw new IllegalArgumentException("Necessario setar a anotassaum @ActivityModel(path=) na Activity");
            }
            Class c = Class.forName(activityViewName);
            activityModel = (BaseActivityModel) c.newInstance();
            mapModel.put(baseActivity.getUuid(), activityModel);
        }
        return activityModel;
    }

    public void cleanActivityModel(BaseActivity baseActivity){
        mapModel.remove(baseActivity.getUuid());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private boolean shouldIgnore(Class clazz){
        Annotation annotation = clazz.getAnnotation(ActivityModel.class);
        if(annotation instanceof ActivityModel){
            ActivityModel modelName = (ActivityModel) annotation;
            return modelName.ignore();
        }
        return false;
    }

}
