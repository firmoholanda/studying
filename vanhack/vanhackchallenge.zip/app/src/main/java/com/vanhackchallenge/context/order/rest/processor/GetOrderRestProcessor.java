package com.vanhackchallenge.context.order.rest.processor;

import android.content.Context;
import android.util.Log;

import com.vanhackchallenge.base.enums.EntityEnums;
import com.vanhackchallenge.base.mvc.service.manager.IRestProcessor;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;
import com.vanhackchallenge.base.retrofit.RetrofitManager;
import com.vanhackchallenge.context.order.dto.OrderDTO;
import com.vanhackchallenge.context.order.rest.service.IOrderService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetOrderRestProcessor implements IRestProcessor<Integer, ReturnModel> {

    private ReturnModel model = new ReturnModel();

    @Override
    public ReturnModel execute(Context context, Integer uid) throws Exception {
        IOrderService orderService = RetrofitManager.get().createService(IOrderService.class);

        orderService.getOrder().enqueue(new Callback<OrderDTO>() {
            @Override
            public void onResponse(Call<OrderDTO> call, Response<OrderDTO> response) {
                Log.i("CODE", ""+response.code());
                OrderDTO orderDTO = null;
                if (response.isSuccessful()) {
                    orderDTO = response.body();
                }
                System.out.println(orderDTO);
                model.setPayload(orderDTO);
            }

            @Override
            public void onFailure(Call<OrderDTO> call, Throwable t) {
                Log.e("ERRO", t.getMessage());
            }
        });

        //Call to rest service

        model.setCommandType(EntityEnums.GET_ORDER);
        //model.setPayload(new OrderDTO("token", "mail@mail.com", "photo"));

        return model;
    }
}
