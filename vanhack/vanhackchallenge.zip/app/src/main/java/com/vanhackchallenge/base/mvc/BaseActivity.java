package com.vanhackchallenge.base.mvc;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.vanhackchallenge.base.mvc.factory.ActivityLayoutFactory;
import com.vanhackchallenge.base.mvc.factory.ActivityModelFactory;
import com.vanhackchallenge.base.mvc.factory.ActivityViewFactory;

import java.util.Observer;
import java.util.UUID;

public abstract class BaseActivity extends AppCompatActivity implements Observer {

    private final String uuid;

    public BaseActivity() {
        uuid = this.getClass().getSimpleName() + UUID.randomUUID().toString();
    }

    public abstract void executeFirstLoad(Bundle savedInstanceState);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ViewDataBinding viewDataBinding = DataBindingUtil.setContentView(this, ActivityLayoutFactory.getActivityLayout(this.getClass()));
        if (this.getActivityView() != null) {
            this.getActivityView().setBaseActivity(this);
            this.getActivityView().initializeViews(viewDataBinding);
            this.getActivityView().setListeners(viewDataBinding);
        }
        this.executeFirstLoad(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (this.getActivityModel() != null){
            this.getActivityModel().addObserver(this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (this.getActivityModel() != null){
            this.getActivityModel().deleteObserver(this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ActivityModelFactory.getInstance().cleanActivityModel(this);
        ActivityViewFactory.getInstance().cleanActivityView(this);
    }

    public String getUuid() {
        return uuid;
    }

    public BaseActivityModel getActivityModel() {
        try {
            return ActivityModelFactory.getInstance().getActivityModel(this);
        } catch (ClassNotFoundException e) {
            Log.e("Error", e.getMessage());
        } catch (InstantiationException e) {
            Log.e("Error", e.getMessage());
        } catch (IllegalAccessException e) {
            Log.e("Error", e.getMessage());
        }
        return null;
    }

    public BaseActivityView getActivityView() {
        try {
            return ActivityViewFactory.getInstance().getActivityView(this);
        } catch (ClassNotFoundException e) {
            Log.e("Error", e.getMessage());
        } catch (InstantiationException e) {
            Log.e("Error", e.getMessage());
        } catch (IllegalAccessException e) {
            Log.e("Error", e.getMessage());
        }
        return null;
    }


}
