package com.vanhackchallenge.base.mvc;

import android.app.Activity;
import android.databinding.ViewDataBinding;

import com.vanhackchallenge.base.mvc.interfaces.IBaseActivityView;

public abstract class BaseActivityView implements IBaseActivityView {

    private BaseActivity baseActivity;

    private ViewDataBinding viewDataBinding;

    public ViewDataBinding getViewDataBinding() {
        return viewDataBinding;
    }

    public void setViewDataBinding(ViewDataBinding viewDataBinding) {
        this.viewDataBinding = viewDataBinding;
    }

    public void setBaseActivity(BaseActivity baseActivity) {
        this.baseActivity = baseActivity;
    }

    public BaseActivity getBaseActivity() {
        return baseActivity;
    }

    @Override
    public void unbind() {
        if (viewDataBinding != null){
            viewDataBinding.unbind();
        }
    }
}
