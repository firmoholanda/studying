package com.vanhackchallenge.context.challengewelcome.model;

import com.vanhackchallenge.base.mvc.BaseActivityModel;

public class WelcomeChallengeActivityModel extends BaseActivityModel {

    public static final String UID_CHANGED = "UID_CHANGED";

    private Integer uid;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
        this.setChanged();
        this.notifyObservers(UID_CHANGED);
    }

}
