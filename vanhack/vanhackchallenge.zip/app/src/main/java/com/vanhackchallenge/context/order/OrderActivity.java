package com.vanhackchallenge.context.order;

import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;

import com.vanhackchallenge.R;
import com.vanhackchallenge.base.mvc.BaseActivity;
import com.vanhackchallenge.base.mvc.annotations.ActivityLayout;
import com.vanhackchallenge.base.mvc.annotations.ActivityModel;
import com.vanhackchallenge.base.mvc.annotations.ActivityView;
import com.vanhackchallenge.base.mvc.interfaces.IRepositoryListener;
import com.vanhackchallenge.base.mvc.processor.IMatchProcessor;
import com.vanhackchallenge.base.mvc.processor.MatchProcessor;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;
import com.vanhackchallenge.context.order.model.OrderActivityModel;
import com.vanhackchallenge.context.order.view.processor.GetOrderProcessor;
import com.vanhackchallenge.context.order.view.processor.ReturnOrderProcessor;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

@ActivityModel(path = "com.vanhackchallenge.context.order.model.OrderActivityModel")
@ActivityView(path = "com.vanhackchallenge.context.order.view.OrderActivityView")
@ActivityLayout(layout = R.layout.activity_order)
public class OrderActivity extends BaseActivity implements IRepositoryListener<ReturnModel> {

    private MatchProcessor matchProcessor;
    private List<IMatchProcessor> processorRepositoryList = new ArrayList<>();
    private List<IMatchProcessor> processorUpdateList = new ArrayList<>();

    @Override
    public void repositorySuccess(ReturnModel abstractModel) {
        new MatchProcessor((ReturnModel) abstractModel, processorRepositoryList).process();
    }

    @Override
    public void repositoryFail(ReturnModel abstractModel) {
        //ProgressDialogManager.getInstance().dismiss();
        new MatchProcessor((ReturnModel) abstractModel, processorRepositoryList).process();
    }

    @Override
    public void update(Observable o, Object data) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {

            @Override
            public void run() {
                new MatchProcessor(data, processorUpdateList).process();
            }
        });
    }

    @Override
    public void executeFirstLoad(Bundle savedInstanceState) {
        this.processorUpdateList.add(new GetOrderProcessor(this));
        this.processorRepositoryList.add(new ReturnOrderProcessor(this));
        new Handler().postDelayed(() -> callOrder(), 1000);

    }

    private void callOrder(){
        ((OrderActivityModel) this.getActivityModel()).setOrderId(this.getIntent().getIntExtra("uid", 0));
    }

}
