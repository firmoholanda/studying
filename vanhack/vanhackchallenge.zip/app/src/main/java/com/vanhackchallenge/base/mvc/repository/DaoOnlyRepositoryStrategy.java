package com.vanhackchallenge.base.mvc.repository;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public class DaoOnlyRepositoryStrategy<I, R extends AbstractModel> extends AbstractRepositoryExecutionStrategy<I, R> {

    /**
     * @param repo
     */
    public DaoOnlyRepositoryStrategy(AbstractRepository<I, R> repo) {
        super(repo);
    }

    /* (non-Javadoc)
     * @see br.com.gvt.infra.patterns.strategy.IRepositoryExecutionStrategy#execute(java.lang.Object)
     */
    @Override
    public void execute(final I i) {
        new Thread(){
            public void run() {
                R r = repository.fromDao(i);
                if (r == null || r.getException() != null){
                    repository.listener.repositoryFail(r);
                } else {
                    repository.listener.repositorySuccess(r);
                }
            }
        }.start();

    }

}
