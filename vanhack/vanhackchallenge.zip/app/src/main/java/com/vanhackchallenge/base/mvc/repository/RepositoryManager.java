package com.vanhackchallenge.base.mvc.repository;

import com.vanhackchallenge.base.mvc.service.model.AbstractModel;

public class RepositoryManager<I, R extends AbstractModel> {

    private AbstractRepository<I, R> repository;

    public RepositoryManager(AbstractRepository<I, R> repository) {
        this.repository = repository;
    };

    public void process(I i) throws Exception {
        repository.execute(i);
    }

}
