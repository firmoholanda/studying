package com.vanhackchallenge.context.order.rest.service;

import com.vanhackchallenge.context.order.dto.OrderDTO;

import retrofit2.Call;
import retrofit2.http.GET;

public interface IOrderService {

    @GET("order/all")
    Call<OrderDTO> getOrder();

    /*
    @GET("authTest")
    Call<MobileRequest> getToken(@Header("Authorization") String token);
    */
}
