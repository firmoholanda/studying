package com.vanhackchallenge.context.order.view.processor;

import com.vanhackchallenge.application.VanHackApplication;
import com.vanhackchallenge.base.mvc.processor.IMatchProcessor;
import com.vanhackchallenge.context.order.OrderActivity;
import com.vanhackchallenge.context.order.command.GetOrderCommand;
import com.vanhackchallenge.context.order.model.OrderActivityModel;

public class ReturnOrderProcessor implements IMatchProcessor {

    private OrderActivity activity;

    public ReturnOrderProcessor(OrderActivity activity){
        this.activity = activity;
    }

    @Override
    public boolean match(Object object) {
        return object != null && OrderActivityModel.ORDER_CHANGED.equals(object);
    }

    @Override
    public Object execute() {
        try {
            Integer orderId = ((OrderActivityModel) activity.getActivityModel()).getOrderId();
            new GetOrderCommand(activity).execute(VanHackApplication.getContext(), orderId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
