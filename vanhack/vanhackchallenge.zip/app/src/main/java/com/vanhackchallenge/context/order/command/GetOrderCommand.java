package com.vanhackchallenge.context.order.command;

import android.content.Context;

import com.vanhackchallenge.base.mvc.command.AbstractCommand;
import com.vanhackchallenge.base.mvc.interfaces.IRepositoryListener;
import com.vanhackchallenge.base.mvc.repository.RepositoryManager;
import com.vanhackchallenge.base.mvc.repository.RestOnlyRepositoryStrategy;
import com.vanhackchallenge.base.mvc.service.model.ReturnModel;
import com.vanhackchallenge.context.order.repository.GetOrderRepository;

public class GetOrderCommand extends AbstractCommand<Integer, ReturnModel> {

    public GetOrderCommand(IRepositoryListener<ReturnModel> listener) {
        super(listener);
    }

    @Override
    public void execute(Context context, Integer uid) throws Exception {
        GetOrderRepository repository = new GetOrderRepository(listener, context);
        repository.setExecutionStrategy(new RestOnlyRepositoryStrategy<Integer, ReturnModel>(repository));
        new RepositoryManager<Integer, ReturnModel>(repository).process(uid);
    }
}
