package com.vanhackchallenge.base.mvc.service.model;

public abstract class AbstractModel {

    protected Exception exception;
    protected Enum commandType;
    protected Object payload;
    protected String httpStatus;
    protected Object friendlyMessage;

    /**
     * @return the commandType
     */
    public Enum getCommandType() {
        return commandType;
    }

    /**
     * @param commandType the commandType to set
     */
    public void setCommandType(Enum commandType) {
        this.commandType = commandType;
    }

    /**
     * @return the payload
     */
    public abstract Object getPayload();

    /**
     * @param payload the payload to set
     */
    public abstract void setPayload(Object payload);

    /**
     * @return the exception
     */
    public Exception getException() {
        return exception;
    }

    /**
     * @param exception the exception to set
     */
    public void setException(Exception exception) {
        this.exception = exception;
    }

    public String getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(String httpStatus) {
        this.httpStatus = httpStatus;
    }

    public Object getFriendlyMessage() {
        return friendlyMessage;
    }

    public void setFriendlyMessage(Object friendlyMessage) {
        this.friendlyMessage = friendlyMessage;
    }
}